# [How to Make a Chess Game with Pygame in Python](https://www.thepythoncode.com/article/make-a-chess-game-using-pygame-in-python)
To run this:
- `pip3 install -r requirements.txt`
- `python main.py`