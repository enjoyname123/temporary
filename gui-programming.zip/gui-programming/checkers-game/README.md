# [How to Make a Checkers Game with Pygame in Python](https://www.thepythoncode.com/article/make-a-checkers-game-with-pygame-in-python)
To run this:
- `pip3 install -r requirements.txt`
- `python3 Main.py`