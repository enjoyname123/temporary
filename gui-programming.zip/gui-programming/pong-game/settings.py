WIDTH, HEIGHT = 990, 450

player_width, player_height  = 20, 90