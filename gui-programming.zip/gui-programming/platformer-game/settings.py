world_map = [
	'                                                                  ',
	'                                                                  ',
	'                t  t                                              ',
	'        X     XXXXXXXXXs                   XX   X                 ',
	' tXXXt     XX         XX                XXXX tt XX                ',
	' XX XX                                      XXXXX                 ',
	'          Xt    t           t  t   X                            G ',
	'        XXXXXX  XXXXs    XXXXXXXXXXX  XX              tt t     XXX',
	' P   XX  X XX X  X XXXt     X XX  XX  XXX  XXXXXXXXs  XXXXXX      ',
	'XXXXXXX  X  X X  X  XXXXXXXXX XX  XX  XXX  XX XX XXXXXXX  X       ',
]

tile_size = 50
WIDTH, HEIGHT = 1000, len(world_map) * tile_size